//
// Created by dsf on 21.03.23.
//

#ifndef MODEL_25_DISPLAY_H
#define MODEL_25_DISPLAY_H

#include <vector>
#include <string>

#include <fmt/core.h>
using namespace std;

template<typename T>
void print_row(const vector<T> &vec, const string &title = "") {
    if (!title.empty())
        fmt::print("{:>10} | ", title);
    for (const auto &el: vec)
        fmt::print("{:>8.2f} | ", (long double) el);
    fmt::println("");
}

template<>
void print_row(const vector<size_t> &vec, const string &title) {
    if (!title.empty())
        fmt::print("{:>10} | ", title);
    for (const auto &el: vec)
        fmt::print("{:>8} | ", (long double) el);
    fmt::println("");
}

template<>
void print_row(const vector<int> &vec, const string &title) {
    if (!title.empty())
        fmt::print("{:>10} | ", title);
    for (const auto &el: vec)
        fmt::print("{:>8} | ", (long double) el);
    fmt::println("");
}

#endif //MODEL_25_DISPLAY_H
