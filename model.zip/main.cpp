#include <vector>
#include <algorithm>

#include <fmt/ranges.h>

#include "models.h"
#include "display.h"
#include "utility.h"
#include "probdist.h"
#include "chen.h"

using namespace std;


// returns list of (xi, count)
vector <size_t> perform_experiments(const pair <vector<int>, size_t> &table_ret, size_t n, size_t experiments_n) {
    auto result_to_count = vector<size_t>(n);
    for (size_t i = 0; i < experiments_n; ++i) {
        result_to_count[model(rnd(), table_ret) - 1] += 1;
    }
    return result_to_count;
}

vector<double> gen_p_values(size_t n, size_t p_value_generations_n, const vector<int> &h0) {
    auto p_values = vector<double>(p_value_generations_n);
    for (size_t i = 0; i < p_value_generations_n; ++i) {
        auto [union_obs, union_exp] = unionize(
                perform_experiments(
                        table_simplest(h0),
                        h0.size(),
                        n),
                to_probabilities(h0),
                n);
        p_values[i] = 1 - pChi(calc_chi_square(union_obs, union_exp), union_obs.size() - 1);
    }

    return p_values;
}

vector<double>
gen_p_values(size_t n, size_t p_value_generations_n, const vector<int> &h0, const vector<int> &h1) {
    auto p_values = vector<double>(p_value_generations_n);
    for (size_t i = 0; i < p_value_generations_n; ++i) {
        auto [union_obs, union_exp] = unionize(
                perform_experiments(
                        table_simplest(h1),
                        h1.size(),
                        n),
                to_probabilities(h0),
                n);
        p_values[i] = 1 - pChi(calc_chi_square(union_obs, union_exp), union_obs.size() - 1);
    }
    sort(begin(p_values), end(p_values));
    fmt::println("{}", p_values);
    return p_values;
}


void introduction(auto k, auto k_size, auto n) {
    fmt::println("k[{}]: {}", k.size(), k);
    auto ret = table_simplest(k);
    fmt::println("x[{}]: {}", ret.first.size(), ret.first);

    auto observed = perform_experiments(ret, k_size, n);

    auto indexes = vector<size_t>(k_size);
    iota(begin(indexes), end(indexes), 1);
    print_row(indexes, "i \\ x_d");
    print_row(k, "k[]");

    print_row(observed, "observed");
    print_row(to_probabilities(k) * n, "expected");

    auto [union_observed, union_expected] = unionize(observed, to_probabilities(k), n);
    print_row(union_observed, "union obs");
    print_row(union_expected, "union exp");

    auto degrees_of_freedom = union_expected.size() - 1;
    fmt::println("Degrees of freedom: {}", union_expected.size());
    auto chi_square = calc_chi_square(union_observed, union_expected);
    fmt::println("Chi-square: {:.4f}", chi_square);
    auto p_value = pChi(calc_chi_square(union_observed, union_expected), degrees_of_freedom);
    fmt::println("p-value: {:.4f}", p_value);

}


void first_part(size_t n, size_t p_value_generations_n, const vector<int> &k) {
    auto p_values = gen_p_values(n, p_value_generations_n, k);

    fmt::println("\n\nLet's calculate {} p-values.", p_value_generations_n);
    fmt::println("{:>5} | {:<7} | {:<7}", "Alpha", "p-value", "Type I Error");
    for (size_t i = 1; i <= 20; ++i) {
        double alpha = 0.05 * i;
        double p_val = static_cast<double>(count_if(begin(p_values), end(p_values),
                                                    [alpha](auto val) {
                                                        return val <= alpha;
                                                    }))
                       / static_cast<double>(p_value_generations_n);
        fmt::println("{:>5.2f} | {:<7.3f} | {:<7.3f}",
                     alpha,
                     p_val,
                     p_val
        );
    }
}

template<typename T>
void second_part(size_t n, size_t p_value_generations_n, vector <T> &k) {
    auto alt_k = slightly_deviate_a_vector(k, 40);

    fmt::v9::println("\n\nLet's calculate Power (aka (1 - (Type II Error))).0\n"
                     "k     {}\n"
                     "alt_k {}", k, alt_k);

    fmt::println("{:>10} | {:<7}", "Alpha", "Power");
    auto alt_p_val = gen_p_values(n, p_value_generations_n, k, alt_k);
    for (size_t i = 1; i <= 20; ++i) {
        double threshold = 0.05 * i;
        double p_val = static_cast<double>(count_if(begin(alt_p_val), end(alt_p_val),
                                                    [threshold](auto val) { return val <= threshold; }))
                       / static_cast<double>(p_value_generations_n);
        fmt::println("{:>10.2f} | {:<7.3f}",
                     threshold,
                     p_val
        );
    }
}


int main(int argc, char *argv[]) {
    if (argc == 1 || string(argv[1]) == "table") {
        fmt::println("Table Simplest\n");

        size_t n = 150;
        size_t k_size = 15;
        int k_limit = 100;
        size_t p_value_generations_n = 1000;

        auto k = generate_randomish_vector(k_size, k_limit);

        introduction(k, k_size, n);
        first_part(n, p_value_generations_n, k);
        second_part(n, p_value_generations_n, k);
    } else if (string(argv[1]) == "chen") {
        fmt::println("Chen\n");

        size_t n = 150;
        size_t k_size = 40;
        size_t p_value_generations_n = 1000;
        size_t m = 10;

        auto k = generate_random_normalized_vector(k_size);

        chen_introduction(k, k_size, n, m);
        chen_first_part(n, p_value_generations_n, k, m);
        chen_second_part(n, p_value_generations_n, k, m);

    } else {
        fmt::println("usage: ./model [ARG]\n"
                     "ARG:\n"
                     "  table -- use simplest table method\n"
                     "  chen -- use Chen method");
    }


    return 0;
}


