//
// Created by dsf on 21.03.23.
//

#ifndef MODEL_25_UTILITY_H
#define MODEL_25_UTILITY_H

#include <vector>
#include <random>

using namespace std;

template<typename T>
vector<T> generate_randomish_vector(size_t size, T limit) {
//    random_device rd;
    static mt19937 mt(0);
    auto vec = vector<T>(size);
    for (auto &el: vec)
        el = mt() % limit; // thats not ok
    return vec;
}

template<typename Float=double>
vector<Float> generate_random_normalized_vector(size_t size) {
//    random_device rd;
    mt19937 mt(0);
    uniform_real_distribution<double> dis(0, 1);
    auto vec = vector<Float>(size);
    for (auto &el: vec)
        el = dis(mt);
    double sum = accumulate(begin(vec), end(vec), 0.0);
    for (auto &el: vec)
        el /= sum;
    return vec;
}

template<typename Float=double>
Float rnd() {
//    random_device rd;
    static mt19937 mt(0);
    static uniform_real_distribution<Float> dis;
    return dis(mt);
}

double normal_rnd() {
    static mt19937 mt(0);
    static normal_distribution<double> dis;
    return dis(mt);
}

template<typename T, typename U>
vector<T> operator*(const vector<T> &vec, U value) {
    auto multiplied = vector<T>(vec.size());
    for (size_t i = 0; i < vec.size(); ++i) {
        multiplied[i] = vec[i] * value;
    }
    return multiplied;
}

template<typename T>
vector<T> slightly_deviate_a_vector(vector<T> vec, T delta) {
    for (auto &el: vec) {
        el += abs(2 * (rnd() - 0.5) * delta);
    }
    return vec;
}

template<typename T>
T sqr(const T &val) {
    return val * val;
}

pair<vector<size_t>, vector<double>>
unionize(const vector<size_t> &observed, const vector<double> &prob, size_t n, double floor = 5) {
    auto expected = prob * n;
    auto unionized_observed = vector<size_t>{};
    auto unionized_expected = vector<double>{};

    auto bucket = pair<size_t, double>{0, 0};
    for (size_t i = 0; i < prob.size(); ++i) {
        if (expected[i] > floor) {
            unionized_observed.push_back(observed[i]);
            unionized_expected.push_back(expected[i]);
        } else {
            bucket.first += observed[i];
            bucket.second += expected[i];
            if (bucket.second >= floor) {
                unionized_observed.push_back(bucket.first);
                unionized_expected.push_back(bucket.second);
                bucket = {0, 0};
            }
        }
    }
    if (bucket.first != 0 || bucket.second != 0) {
        if (unionized_observed.empty()) {
            unionized_observed.push_back(0);
            unionized_expected.push_back(0);
        }
        unionized_observed.back() += bucket.first;
        unionized_expected.back() += bucket.second;
    }

    return {unionized_observed, unionized_expected};
}

double calc_chi_square(const vector<size_t> &obs, const vector<double> &exp) {
    double chi_square = 0;
    for (size_t i = 0; i < obs.size(); ++i)
        chi_square += sqr(static_cast<double>(obs[i]) - exp[i]) / exp[i];
    return chi_square;
}

template<typename T>
vector<double> to_probabilities(const vector<T> &vec) {
    auto probabilities = vector<double>(vec.size());
    T sum = accumulate(begin(vec), end(vec), static_cast<T>(0));
    for (size_t i = 0; i < vec.size(); ++i)
        probabilities[i] = static_cast<double>(vec[i]) / sum;
    return probabilities;
}

#endif //MODEL_25_UTILITY_H
