//
// Created by dsf on 28.03.23.
//

#ifndef MODEL_CHEN_H
#define MODEL_CHEN_H

#include "utility.h"
#include "models.h"
#include "probdist.h"
#include "display.h"

#include <fmt/ranges.h>

// returns list of (xi, count)
vector<size_t>
chen_perform_experiments(const pair<vector<double>, vector<double>> &chen_ret, size_t n, size_t experiments_n,
                         size_t m) {
    auto result_to_count = vector<size_t>(n);
    for (size_t i = 0; i < experiments_n; ++i) {
        result_to_count[model(m, rnd(), chen_ret) - 1] += 1;
    }
    return result_to_count;
}

vector<double>
chen_gen_p_values(size_t n, size_t p_value_generations_n, const vector<double> &k, size_t m) {
    auto p_values = vector<double>(p_value_generations_n);
    for (size_t i = 0; i < p_value_generations_n; ++i) {
        auto [union_obs, union_exp] = unionize(
                chen_perform_experiments(
                        cheng_asau_method(k, m),
                        k.size(),
                        n,
                        m),
                k,
                n);
        p_values[i] = 1 - pChi(calc_chi_square(union_obs, union_exp), union_obs.size() - 1);
    }

    return p_values;
}

vector<double>
chen_gen_p_values(size_t n, size_t p_value_generations_n, const vector<double> &h0, const vector<double> &h1,
                  size_t m) {
    auto p_values = vector<double>(p_value_generations_n);
    for (size_t i = 0; i < p_value_generations_n; ++i) {
        auto [union_obs, union_exp] = unionize(
                chen_perform_experiments(
                        cheng_asau_method(h1, m),
                        h1.size(),
                        n, m),
                h0,
                n);
        p_values[i] = 1 - pChi(calc_chi_square(union_obs, union_exp), union_obs.size() - 1);
    }

    return p_values;
}

// returns list of (xi, count)
vector<size_t>
chen_perform_experiments(const pair<vector<double>, const vector<double>> &chen_ret, size_t n, size_t experiments_n,
                         size_t m) {
    auto result_to_count = vector<size_t>(n);
    for (size_t i = 0; i < experiments_n; ++i) {
        result_to_count[model(m, rnd(), chen_ret) - 1] += 1;
    }
    return result_to_count;
}

void chen_introduction(const vector<double> &k, size_t k_size, size_t n, size_t m) {
    fmt::println("k[{}]: {}", k.size(), k);
    auto ret = cheng_asau_method(k, m);
    fmt::println("x[{}]: {}", ret.first.size(), ret.first);

    auto observed = chen_perform_experiments(ret, k_size, n, m);

    auto indexes = vector<size_t>(k_size);
    iota(begin(indexes), end(indexes), 1);
    print_row(indexes, "i \\ x_d");
    print_row(k, "k[]");

    print_row(observed, "observed");
    print_row(to_probabilities(k) * n, "expected");

    auto [union_observed, union_expected] = unionize(observed, to_probabilities(k), n);
    print_row(union_observed, "union obs");
    print_row(union_expected, "union exp");

    auto degrees_of_freedom = union_expected.size() - 1;
    fmt::println("Degrees of freedom: {}", union_expected.size());
    auto chi_square = calc_chi_square(union_observed, union_expected);
    fmt::println("Chi-square: {:.4f}", chi_square);
    auto p_value = pChi(calc_chi_square(union_observed, union_expected), degrees_of_freedom);
    fmt::println("p-value: {:.4f}", p_value);

}


void chen_first_part(size_t n, size_t p_value_generations_n, const vector<double> &k, size_t m) {
    auto p_values = chen_gen_p_values(n, p_value_generations_n, k, m);

    fmt::println("\n\nLet's calculate {} p-values.", p_value_generations_n);
    fmt::println("{:>5} | {:<7} | {:<7}", "Alpha", "p-value", "Type I Error");
    for (size_t i = 1; i <= 20; ++i) {
        double alpha = 0.05 * i;
        double p_val = static_cast<double>(count_if(begin(p_values), end(p_values),
                                                    [alpha](auto val) {
                                                        return val <= alpha;
                                                    }))
                       / static_cast<double>(p_value_generations_n);
        fmt::println("{:>5.2f} | {:<7.3f} | {:<7.3f}",
                     alpha,
                     p_val,
                     p_val
        );
    }
}

void chen_second_part(size_t n, size_t p_value_generations_n, const vector<double> &k, size_t m) {
    auto alt_k = to_probabilities(slightly_deviate_a_vector(k, 0.025));
    fmt::v9::println("\n\nLet's calculate Power (aka (1 - (Type II Error))).\n"
                     "H_0    {}\n"
                     "H_1    {}", k, alt_k);

    fmt::println("{:>10} | {:<7}", "Alpha", "Power");
    auto alt_p_val = chen_gen_p_values(n, p_value_generations_n, k, alt_k, m);
    for (size_t i = 1; i <= 20; ++i) {
        double threshold = 0.05 * i;
        double p_val = static_cast<double>(count_if(begin(alt_p_val), end(alt_p_val),
                                                    [threshold](auto val) { return val <= threshold; }))
                       / static_cast<double>(p_value_generations_n);
        fmt::println("{:>10.2f} | {:<7.3f}",
                     threshold,
                     p_val
        );
    }
}


#endif //MODEL_CHEN_H
