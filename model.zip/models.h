//
// Created by dsf on 28.03.23.
//

#ifndef MODEL_25_MODELS_H
#define MODEL_25_MODELS_H

#include <algorithm>
#include <vector>
#include <numeric>

using namespace std;

//  p.13 https://drive.google.com/drive/folders/1CRJl-eyG18mlLgX8zhfZMS8HLs17bOVo
//  1       2       ...
//  k[0]    k[1]    ...
pair<vector<int>, size_t> table_simplest(const vector<int> &k) {
    int N = accumulate(begin(k), end(k), static_cast<int>(0));
    auto table = vector<int>(N);

    size_t i = 1, j = 1, l = k[0];
    while (l <= N) {
        while (i <= l) {
            table[i - 1] = j;
            i = i + 1;
        }
        j = j + 1;
        l = l + k[j - 1];
    }
    return {table, N};
}

int model(double alpha, const pair<vector<int>, size_t> &table_simplest_return) {
    auto d = static_cast<size_t>(alpha * table_simplest_return.second);
    return table_simplest_return.first[min(d, table_simplest_return.second - 1)];
}


// p. 19 https://drive.google.com/drive/folders/1CRJl-eyG18mlLgX8zhfZMS8HLs17bOVo
pair<vector<double>, vector<double>> cheng_asau_method(const vector<double> &p, size_t m) {
    auto s = vector<double>(p.size()); // acc sums
    s[0] = p[0];
    for (size_t i = 1; i < p.size(); ++i)
        s[i] = s[i - 1] + p[i];

    auto r = vector<double>(m); // add arr
    size_t i = 1;
    for (size_t j = 1; j <= m; ++j) {
        while (static_cast<double>(m) * s[i - 1] + 1 <= static_cast<double>(j))
            i += 1;
        r[j - 1] = static_cast<double>(i);
    }

    return {s, r};
}

size_t model(size_t m, double alpha, const pair<vector<double>, vector<double>> &chen_method_return) {
    auto &[s, r] = chen_method_return;
    size_t j = static_cast<double>(m) * alpha, i = r[j - 1];
    while (alpha > s[i - 1])
        i += 1;
    return i;
}

#endif //MODEL_25_MODELS_H
